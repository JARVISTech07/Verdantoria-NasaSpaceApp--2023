<?php return array('dependencies' => array(), 'version' => 'd4cdced5a2afff4a8cc2');
