<?php return array('dependencies' => array(), 'version' => '9d287166f699a66eff3b');
