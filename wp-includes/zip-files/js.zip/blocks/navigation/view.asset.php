<?php return array('dependencies' => array(), 'version' => 'b0c5026864ec3616bae7');
